# UI/UX Redesign Notes — Cognitive Radiology Assistant

## Objective

Reduce friction in the primary desktop workflow: select a chest X-ray, provide clinical context, run the pipeline, and review generated output alongside reference annotations where applicable.

## Changes implemented

### 1. Clearer information hierarchy
- Replaced the dense title bar with a product header, short descriptor, model-state indicator, and global actions.
- Added a compact four-step workflow strip to orient first-time users.
- Standardized section headings, field labels, muted helper text, spacing, borders, and button hierarchy.

### 2. Input workflow
- Grouped sample selection, image preview, image metadata, file browsing, and clinical context in one dedicated panel.
- Added a visible filename and pixel-dimension summary after an image is selected.
- Added a clearer empty state and improved image-preview scaling when the window is resized.
- Clarified that benchmark reference outputs are test annotations, not model predictions.
- Made sample image paths resolve relative to the project directory rather than the process working directory.

### 3. Results workflow
- Renamed tabs to concise task labels: Model output, Reference, and Calibration.
- Separated the generated report from the pathology-score list.
- Put pathology scores in a scrollable region so long result sets do not compress the report.
- Displayed every returned pathology score and made threshold status explicit, rather than silently hiding scores below threshold.
- Added text clarifying that model scores are not confirmed diagnoses and may not be calibrated clinical probabilities.
- Added a result-state indicator for waiting, in-progress, complete, reference-only, and failed states.

### 4. Calibration usability
- Grouped preset selection and threshold sliders under a dedicated calibration tab.
- Added helper text explaining that threshold changes affect report grounding, not trained model weights.
- Preserved the existing preset profiles and threshold behavior.

### 5. Visual system
- Applied a restrained clinical-workspace palette with neutral surfaces, blue primary actions, clear focus states, and semantic status colors.
- Increased consistency of control heights, radii, typography, and spacing.
- Removed team branding from the application title to keep the product identity focused.

## UX and safety decisions

- Benchmark outputs remain an explicitly selected test/reference mode and are labelled as not being model predictions.
- The model-inference path remains intact for other images.
- The interface includes a research-use disclaimer and recommends qualified clinical review.
- Score bars are styled as neutral visual indicators; threshold state is shown separately from the score itself.

## Validation performed

- `scripts/gui_app.py` passes Python syntax compilation.
- Static AST inspection confirms the main window and key UI methods are present.
- A live GUI render could not be performed in the current build environment because PySide6 is not installed here. Please launch on the target environment with the project's dependencies installed and verify at the target display resolution.

## Recommended follow-up usability checks

1. Verify the layout at 1120×760 and at a typical 1366×768 laptop resolution.
2. Check keyboard navigation through sample selection, file browsing, clinical context, tabs, and Run analysis.
3. Confirm model-load and inference errors are understandable to a non-developer.
4. Test large and unusually tall/wide image files for preview clipping.
5. Ask 3–5 representative users to complete the image-to-results workflow without guidance and record completion time, misclicks, and points of uncertainty.
